
package com.innotall.themeray.portlet.slider.action;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletConfig;
import javax.portlet.PortletPreferences;
import com.liferay.portal.kernel.portlet.DefaultConfigurationAction;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.Constants;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portlet.PortletPreferencesFactoryUtil;

public class ConfigurationActionImpl extends DefaultConfigurationAction {

	@Override
	public void processAction(
			PortletConfig portletConfig, ActionRequest actionRequest,
			ActionResponse actionResponse)
		throws Exception {
		
		String cmd = ParamUtil.getString(actionRequest, Constants.CMD);

		if (!cmd.equals(Constants.UPDATE)) {
			return;
		}

		
		String portletResource = ParamUtil.getString(
				actionRequest, "portletResource");
		PortletPreferences preferences =
				PortletPreferencesFactoryUtil.getPortletSetup(
					actionRequest, portletResource);

		/*
		 *  Getting and storing the slider parameters
		 */
		setSliderParams( actionRequest,  preferences);
		/*
		 *  Getting and storing the slider contents
		 */
		setSliderContents( actionRequest,  preferences);
		SessionMessages.add(actionRequest,portletConfig.getPortletName() +SessionMessages.KEY_SUFFIX_REFRESH_PORTLET,portletResource);
		if (SessionErrors.isEmpty(actionRequest)) {
			preferences.store();			
		}
	}
	protected void setSliderParams(ActionRequest actionRequest, PortletPreferences preferences) throws Exception{
		/*
		 *  Getting the slider parameters from configuration form
		 */
				String animationSpeed = ParamUtil.getString(actionRequest,"animationSpeed");
				String slideShowSpeed = ParamUtil.getString(actionRequest,"slideShowSpeed");
				String itemWidth = ParamUtil.getString(actionRequest,"itemWidth");
				String maxItems = ParamUtil.getString(actionRequest,"maxItems");
				String move = ParamUtil.getString(actionRequest,"move");
				String manualControlSelector = ParamUtil.getString(actionRequest,"manualControlSelector");
				String animationType = ParamUtil.getString(actionRequest,"animationType");
				String animationDirection = ParamUtil.getString(actionRequest,"animationDirection");
				String pauseOnHover = ParamUtil.getString(actionRequest,"pauseOnHover");
				String loop = ParamUtil.getString(actionRequest,"loop");
				String pagination = ParamUtil.getString(actionRequest,"pagination");
				String nextPrevControls = ParamUtil.getString(actionRequest,"nextPrevControls");
				String autoShow = ParamUtil.getString(actionRequest,"autoShow");
				String smoothHeight = ParamUtil.getString(actionRequest,"smoothHeight");
				
				/*
				 *  Setting the slider parameters from configuration form as portlet preferences
				 */

				preferences.setValue("animationSpeed", animationSpeed);
				preferences.setValue("slideShowSpeed", slideShowSpeed);
				preferences.setValue("itemWidth" , itemWidth);		
				preferences.setValue("maxItems", maxItems);
				preferences.setValue("move", move);
				preferences.setValue("manualControlSelector", manualControlSelector);
				preferences.setValue("animationType", animationType);
				preferences.setValue("animationDirection", animationDirection);
				preferences.setValue("pauseOnHover", pauseOnHover);
				preferences.setValue("loop", loop);
				preferences.setValue("pagination" , pagination);		
				preferences.setValue("nextPrevControls", nextPrevControls);
				preferences.setValue("autoShow", autoShow);
				preferences.setValue("smoothHeight", smoothHeight);
				preferences.setValue("animationType", animationType);
				preferences.setValue("animationDirection", animationDirection);
	}
	protected void setSliderContents(ActionRequest actionRequest, PortletPreferences preferences) throws Exception{
		String slidesIndexesParam = ParamUtil.getString(actionRequest, "slidesIndexs");
		/*
		 *  slider Contents storing
		 */
		String sliderType = ParamUtil.getString(actionRequest,"sliderType");
		preferences.setValue("sliderType", sliderType);
		/*
		 *  fixed-text-sliding-image slider
		 */
		String sliderFixedText = ParamUtil.getString(actionRequest,"sliderFixedText");
		String sliderFixedDescription = ParamUtil.getString(actionRequest,"sliderFixedDescription");		
		preferences.setValue("sliderFixedText", sliderFixedText);
		preferences.setValue("sliderFixedDescription", sliderFixedDescription);
		
		int[]  slidesIndexes=StringUtil.split(slidesIndexesParam, 0);
		preferences.setValue("slidesIndexs", slidesIndexesParam);
		int i=1;
		for(int slideIndexe : slidesIndexes){
			/*
			 *  Getting the sliders contents from configuration form as portlet preferences
			 */
			String slideText = ParamUtil.getString(actionRequest,"slideText"+slideIndexe);
			String slideDescription = ParamUtil.getString(actionRequest,"slideDescription"+slideIndexe);
			String slideImage = ParamUtil.getString(actionRequest,"slideImage"+slideIndexe);
			String slideImageWidth = ParamUtil.getString(actionRequest,"slideImageWidth"+slideIndexe);
			String slideImageHeight = ParamUtil.getString(actionRequest,"slideImageHeight"+slideIndexe);
			String slideImageLink = ParamUtil.getString(actionRequest,"slideImageLink"+slideIndexe);
			String slideImageCaption = ParamUtil.getString(actionRequest,"slideImageCaption"+slideIndexe);
			String slideButtonCaption = ParamUtil.getString(actionRequest,"slideButtonCaption"+slideIndexe);
			String slideButtonLink = ParamUtil.getString(actionRequest,"slideButtonLink"+slideIndexe);		
			// Storing the sliders contents from configuration form
			preferences.setValue("slideText" +i, slideText);
			preferences.setValue("slideDescription" +i, slideDescription);
			preferences.setValue("slideImage" +i, slideImage);		
			preferences.setValue("slideImageWidth" +i, slideImageWidth);
			preferences.setValue("slideImageHeight" +i, slideImageHeight);
			preferences.setValue("slideImageLink" +i, slideImageLink);
			preferences.setValue("slideImageCaption" +i, slideImageCaption);
			preferences.setValue("slideButtonCaption" +i, slideButtonCaption);
			preferences.setValue("slideButtonLink" +i, slideButtonLink);

			i++;
		}
	}
}